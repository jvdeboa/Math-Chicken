extends CharacterBody2D

const SPEED = 300.0
const JUMP_VELOCITY = -400.0

@onready var anim := $AnimationPlayer
@onready var texture := $CuteChicken2Idle

func _physics_process(delta: float) -> void:
	# Gravidade
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Pulo
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Movimento
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
	
	animation_test(direction)
	
	move_and_slide()

func animation_test(direction: float) -> void:
	# 1. Inverte a imagem se estiver se movendo
	if direction != 0:
		texture.flip_h = (direction < 0)

	# 2. Controla qual animação toca (apenas se estiver no chão)
	if is_on_floor():
		if velocity.x != 0:
			anim.play("run")
		else:
			anim.play("Idle")
