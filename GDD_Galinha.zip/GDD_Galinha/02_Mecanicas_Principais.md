# 2️⃣ Mecânicas Principais

## 2.1 Movimento da Galinha

### Controles
- **Movimento lateral**: Setas ou WASD
- **Pulo**: Espaço
- **Física**: Gravidade básica, plataforma tradicional
- **Velocidade**: Moderada (não tão rápida quanto Void Knight)

### Animações
- Walk (loop ao andar)
- Jump (salta e cai)
- Idle (parado, anima cabeça?)

---

## 2.2 Sistema de Contas

### Como funciona:
1. Uma **conta matemática** aparece no **topo da tela**  
   Exemplo: `5 + 3 = ?`

2. **Blocos numéricos flutuam** aleatoriamente no mundo

3. Jogador precisa **pegar o bloco correto**  
   Neste caso: bloco `8`

4. Ao pegar o bloco certo → **fase completa**  
   Vai para próxima fase

### O que acontece com números errados?
- Pegar número errado → **volta ao início da fase** (ou perde vida?)
- ⚠️ **DECIDIR**: Game Over imediato? Ou vidas/tentativas?

---

## 2.3 Blocos Numéricos

### Visual
- Cubos com **números grandes e legíveis**
- Cores claras (branco, amarelo, etc.)
- Brilham ou mudam cor ao serem pegados

### Comportamento
- **Flutuam lentamente** no mundo (não fixos)
- Não são sólidos (galinha passa por eles)
- Ao encostar → ativa a colisão

### Tipos de Blocos
- ✅ **Bloco correto**: Brilha/muda cor ao pegar
- ❌ **Blocos errados**: Apenas passam ou desaparecem

### Spawn
- Aleatório em cada fase
- Posicionados pra não ficarem impossíveis de pegar
- Alguns mais escondidos (progressão)

---

## 2.4 Progressão de Dificuldade

### Fases por Tipo de Operação

| Fases | Tipo | Exemplo | Dificuldade |
|-------|------|---------|-------------|
| 1-3 | Adição simples | 2+1=?, 3+2=? | Muito fácil |
| 4-6 | Subtração simples | 5-2=?, 8-3=? | Fácil |
| 7-9 | Adição + Subtração | 2+3-1=?, 10-5+2=? | Médio |
| 10+ | Multiplicação/Divisão | 3×2=?, 10÷2=? | Difícil |

### O que fica mais difícil:
- 🔢 **Contas mais complexas** (números maiores, mais operações)
- 🗺️ **Blocos mais espalhados/escondidos** (precisam explorar mais)
- 🧱 **Obstáculos no caminho** (plataformas móveis, gaps maiores)
- 👿 **Inimigos que movem** (opcional, se tempo permitir)
- ⏱️ **Possível limite de tempo** (muito depois)

---

## 2.5 Feedback & Satisfação

### Som
- ✅ Ao pegar bloco correto: Som positivo, alegre
- ❌ Ao pegar bloco errado: Som de erro/buzzer
- 🎉 Ao completar fase: Fanfarra curta
- 🚫 Ao falhar: Reboot suave

### Visual
- Bloco brilha ao ser pegado
- Galinha pula de alegria ao completar
- Tela pisca sutilmente ao cometer erro
- Transição suave entre fases

### Ritmo
- Sem pressa excessiva (não é reflexo rápido demais)
- Tempo suficiente pra pensar + agir
- Reward imediato (feedback em <200ms)

---

## Links Relacionados
- [[03_Mundo_Ambientacao]] - Onde isso tudo acontece
- [[05_Fluxo_Gameplay]] - O fluxo completo
- [[06_Escopo_MVP]] - Quais mecânicas são MVP vs bônus
