# 1️⃣2️⃣ Notas Importantes

## 12.1 Prioridades (Ordem de Importância)

### 🔴 CRÍTICO (Sem isto = projeto falha)
1. **Galinha se move** (esquerda/direita/pulo)
2. **Conta aparece na tela**
3. **Blocos pegáveis**
4. **Verificação funciona** (acerto vs erro)
5. **Transição entre fases**

### 🟡 IMPORTANTE (Muito bom ter)
6. Menu inicial
7. Feedback visual (som/animação)
8. 5+ fases completas
9. Progressão de dificuldade

### 🟢 LEGAL (Nice to have)
10. Animações suaves
11. Múltiplos biomas
12. Música
13. Efeitos especiais

**Mantra**: Se tiver que remover algo, remove de baixo pra cima

---

## 12.2 Desafios Comum & Soluções

### Desafio: Godot trava/não abre
**Sintomas**: Erro ao iniciar, crash ao fazer edit
**Causas possíveis**:
- Versão Godot errada (certifique que é 4.x)
- Projeto corrompido (arquivo .tscn invalid)
- Plugin incompatível

**Soluções**:
1. [ ] Reinstalar Godot 4.1+ (versão estável)
2. [ ] Criar novo projeto, copiar scripts um por um
3. [ ] Verificar console (F7) pra erro específico
4. [ ] YouTube "Godot 4 won't open" + seu erro

### Desafio: Physics bugada (galinha cai errado)
**Sintomas**: Pulo estranha, atravessa plataforma, fica preso
**Causas**:
- Collision shapes sobrepostas
- Gravity muito alta/baixa
- Tamanho do sprite != tamanho do collision

**Soluções**:
1. [ ] Simplificar collision (usar Rectangle ao invés de Custom)
2. [ ] Testar valores: Gravity = 800, JumpForce = -400
3. [ ] Visualizar collision (Debug → Visibility)
4. [ ] Resetar tudo e fazer do zero (rápido, às vezes)

### Desafio: Blocos não pegam
**Sintomas**: Galinha passa pelo bloco, colisão não funciona
**Causas**:
- Area2D sem collision shape
- Sem sinal `area_entered` conectado
- Ordem de nós errada

**Soluções**:
1. [ ] Verificar: Block tem Area2D + CollisionShape2D?
2. [ ] Inspector: Area2D tem signal conectado?
3. [ ] Console: `print("bloco pegou")` pra testar
4. [ ] Testar em cena só do bloco (isolar problema)

### Desafio: Menu não funciona
**Sintomas**: Botão não responde, clica mas nada acontece
**Causas**:
- Button sem sinal `pressed` conectado
- Script sem função `_on_button_pressed()`
- Cena não instancia direito

**Soluções**:
1. [ ] Conectar sinal manualmente (Button → pressed → _on_pressed)
2. [ ] Print debug antes do `get_tree().change_scene_to_file()`
3. [ ] Testar botão em cena isolada

### Desafio: Performance lenta (lag)
**Sintomas**: FPS baixo, tela travando, gaguejo
**Causas**:
- Muitos blocos instanciados
- Sprite muito grande
- Loop infinito em script

**Soluções**:
1. [ ] Limitar blocos (max 5-7 por fase)
2. [ ] Reduzir resolução sprite (64x64 → 32x32)
3. [ ] Debugger → Profiler (ver o que tá lento)
4. [ ] Remover animações complexas

### Desafio: Build não funciona (.exe crasheia)
**Sintomas**: Jogo funciona em Godot, mas .exe dá erro
**Causas**:
- Caminho de arquivo relativo errado
- Asset faltando no build
- Versão do Godot diferente

**Soluções**:
1. [ ] Verificar Project → Export → Inclusions (arquivo tá lá?)
2. [ ] Usar caminhos relativos: `res://` (não caminho PC)
3. [ ] Fazer build novamente (às vezes resolve)
4. [ ] Testar em PC diferente

---

## 12.3 Dicas de Debugging

### Usar Print
```gdscript
# Simples
print("Blocos: ", blocks.size())

# Condicional
if correct_answer != block_number:
    print("ERRO: esperava %d, pegou %d" % [correct_answer, block_number])
```

### Remover Print Depois
(Antes de entregar, não deixar console poluído)

### Usar Debugger
- F7 pra abrir Debugger
- Breakpoints (linha vermelha)
- Step into/over

### Visualizar Colisões
- Debug → GDScript → Mostrar Colisões
- Vira tudo vermelho (ajuda a entender)

---

## 12.4 Possíveis Dificuldades & Pano B

### Se faltar tempo na Semana 1
**Plano B**: Só movimento, sem pulo (depois adiciona)
- Foco: Setas esquerda/direita funcionam
- Ignore: Gravidade, pulo, câmera
- Próximo: Adiciona pulo (sexta)

### Se faltar na Semana 2
**Plano B**: Sistema de contas simples (prints)
- Label mostra conta (funciona)
- Verificação: Só print do resultado
- Ignore: Feedback visual (somógrafos)
- Próximo: Adiciona feedback

### Se faltar na Semana 3 (CRÍTICO)
**Prioridades**:
1. 3 fases funcionando 100% (não 5 com bugs)
2. Menu funciona (não fancy)
3. Jogo não crasheia
4. Pode remover: Sons, animações, mais fases

**Resultado**: MVP 100% funcional (bom o suficiente)

---

## 12.5 Checklist de Qualidade Antes de Entregar

### Funcionalidade
- [ ] Jogo abre sem erros
- [ ] Menu funciona (Jogar/Sair)
- [ ] Fase 1 funciona completamente
- [ ] Pode completar fase 1 (pegar bloco certo)
- [ ] Prossegue para fase 2
- [ ] Todas as fases até a última funcionam
- [ ] Sem crashes em situação normal

### Jogabilidade
- [ ] Controles responsivos (sem delay)
- [ ] Feedback claro ao acertar (visual ou som)
- [ ] Feedback claro ao errar
- [ ] Dificuldade progressiva (percebe diferença entre fases)

### Visual
- [ ] Galinha visível
- [ ] Blocos visíveis e legíveis (número grande)
- [ ] Conta na tela legível (mínimo 32pt)
- [ ] Sem cores muito similares (legível)

### Código
- [ ] Scripts principais comentados (main logic)
- [ ] Sem warnings em console (limpo)
- [ ] Nomes de variáveis claros
- [ ] Sem código duplicado (DRY)

### Documentação
- [ ] Este GDD completo
- [ ] README.md (como jogar)
- [ ] Arquivo projeto Godot salvo
- [ ] Build executável pronto

### Apresentação Escolar
- [ ] Screenshot de 3 fases diferentes
- [ ] Vídeo gameplay 30-60s (YouTube ou arquivo)
- [ ] Breve relato (o que funcionou, desafios)
- [ ] Créditos (quem fez o quê)

---

## 12.6 Pano C: Se Falhar Completamente

(Cenário pessimista, mas prepare-se)

### Se não conseguir nada funcionando até sexta (semana 3)
**Não desista**:
1. Coloque um vídeo mostrando o "potencial" (desenhos, etc)
2. Apresente o GDD (vale como documentação)
3. Explique os desafios que enfrentou
4. Mostre código (mesmo que não funcione)
5. Demonstre ENTENDIMENTO do projeto

**Professor vai valorizar**:
- Esforço
- Documentação
- Tentativa honesta
- Aprendizado mesmo que quebrado

---

## 12.7 Comunicação com Professora/Professor

### Se Travar numa Coisa
- ✅ Pedir ajuda (escrever email descrevendo erro)
- ✅ Mostrar código
- ✅ Descrever o que tentou

### Exemplo Email
```
Olá professor,

Estou com dificuldade em fazer a colisão dos blocos
funcionar no Godot. O bloco é um Area2D com CollisionShape2D,
e a galinha é um CharacterBody2D. Quando a galinha passa
pelo bloco, a colisão não dispara.

Tentei:
1. Adicionar sinal area_entered
2. Verificar collision layers
3. Simplificar shapes

Código: [colar snippet]
Erro: [descrever problema]

Alguma dica?
Obrigado.
```

---

## 12.8 Cronograma de Recuperação

Se atrasar em alguma semana:

### Se Semana 1 Atrasou
- Semana 2 Terça: Termina o que faltou da Semana 1
- Semana 2 Sexta: Pula pra Contas (recupera)
- Risco: Fases menos polidas

### Se Semana 2 Atrasou
- Semana 3 Terça: Termina Semana 2
- Semana 3 Sexta: Fases + Testes
- Risco: Menos fases ou polish reduzido

### Se Semana 3 Começar Ruim
- Quinta (véspera)? Maratona se possível
- Sexta Manhã: Último push
- Sexta Tarde: Testes + Documentação
- Noite: Entrega

---

## 12.9 Pós-Desenvolvimento: Feedback Loop

### Depois de Terminar
Importante: **Testar com alguém que não fez**
1. Peça pra colega/amigo jogar
2. Anote: O que confundiu?
3. Ajuste (se tempo permitir)

### Iteração Rápida
- Feature tá confundindo? Remove ou esclarece
- Dificuldade muito fácil/difícil? Ajusta
- Crashing em situação X? Hotfix

---

## 12.10 Filosofia: Simplicidade é Força

### Mantra pra Semanas 1-3:
```
"Simples > Bonito"
"Funcional > Perfeito"
"Terminado > Inacabado"
"Testado > Pronto"
```

### Não faça:
❌ 10 fases bugadas
❌ 1 fase perfeita
❌ Efeitos visuais complexos
❌ Código complicado

### Faça:
✅ 3 fases funcionais
✅ Menu simples
✅ Feedback claro
✅ Código comentado

**Resultado final**: MVP 100% funcional < Jogo perfeito com bugs

---

## Links Relacionados
- [[06_Escopo_MVP]] - Prioridades técnicas
- [[07_Cronograma]] - Timeline realista
- [[09_Arquitetura_Godot]] - Implementação técnica
