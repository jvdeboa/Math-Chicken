# 🐔 GDD - Galinha Matemática

**Projeto Escolar | Trabalho de Godot**  
**Data Limite: 4 de setembro**  
**Equipe: Dupla**  
**Tempo disponível: 6 horas/semana (terças e sextas, 3h cada)**

---

## 📚 Navegação Principal

### 1️⃣ **Visão Geral**
- [[01_Visao_Geral]] - Conceito, objetivo educacional, plataforma

### 2️⃣ **Gameplay & Mecânicas**
- [[02_Mecanicas_Principais]] - Movimento, blocos, contas, dificuldade
- [[03_Mundo_Ambientacao]] - Tema, estrutura, elementos visuais

### 3️⃣ **Design & Interface**
- [[04_UI_UX]] - HUD, menus, feedback
- [[05_Fluxo_Gameplay]] - Diagrama do fluxo

### 4️⃣ **Produção**
- [[06_Escopo_MVP]] - O que fazer até 4 de setembro
- [[07_Cronograma]] - Semana por semana
- [[08_Divisao_Tarefas]] - Quem faz o quê

### 5️⃣ **Técnico**
- [[09_Arquitetura_Godot]] - Estrutura de cenas e scripts
- [[10_Recursos_Assets]] - Sprites, sons, fontes

### 6️⃣ **Referência**
- [[11_Inspiracoes]] - Jogos de referência
- [[12_Notas_Importantes]] - Dificuldades, prioridades, soluções

### 7️⃣ **Rastreamento**
- [[13_Revisoes_Ajustes]] - Espaço para anotar mudanças

---

## ⚡ Quick Start
1. Leia [[01_Visao_Geral]] primeiro
2. Entenda [[02_Mecanicas_Principais]]
3. Verifique [[06_Escopo_MVP]] pro escopo realista
4. Acompanhe [[07_Cronograma]]
5. Use [[08_Divisao_Tarefas]] pra coordenar

---

**Status**: ✅ Pronto para começar!  
**Última atualização**: Hoje
