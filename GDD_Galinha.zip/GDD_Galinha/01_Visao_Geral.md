# 1️⃣ Visão Geral do Jogo

## Conceito Central
Um **platformer educacional indireto** onde o jogador controla uma **galinha** em um **mundo aberto**. Para completar desafios e progredir, precisa **pegar blocos numéricos flutuando** para resolver **contas matemáticas** que aparecem na tela.

## Objetivo Educacional (Indireto)
Treina:
- 🧠 Cálculo mental rápido
- 🔢 Lógica numérica
- ⚡ Coordenação (timing + movimento)
- 💪 Persistência na resolução de problemas

## Público-alvo
- 📚 Escolar (trabalho de classe)
- 👶 Faixa etária: 8+ anos (conceitual)

## Plataforma
- 🎮 **Godot 4**
- 💻 **Desktop** (Windows/Linux/Mac)

## Dados do Projeto
| Aspecto | Detalhe |
|--------|---------|
| **Prazo** | 4 de setembro |
| **Equipe** | Dupla |
| **Tempo/semana** | 6 horas (terças & sextas, 3h cada) |
| **Gênero** | Platformer 2D |
| **Tema** | Escola/Classroom (mundo aberto) |
| **Personagem** | Galinha |
| **Mecânica Core** | Pegar blocos numéricos pra resolver contas |

## Links Relacionados
- [[02_Mecanicas_Principais]] - Como o jogo funciona
- [[03_Mundo_Ambientacao]] - Visual e cenários
- [[06_Escopo_MVP]] - O que vocês vão entregar
