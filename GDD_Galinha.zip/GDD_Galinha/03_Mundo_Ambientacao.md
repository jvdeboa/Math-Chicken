# 3️⃣ Mundo & Ambientação

## 3.1 Tema
**Escola/Classroom** com elementos naturais

### Referências Visuais
- Quadros negros e brancos
- Carteiras e mesas
- Livros, lápis, borrachas
- Plantas (pátio, jardim escolar)
- Cercas, árvores, grama

### Tom
- Amigável e educativo
- Não infantilista demais
- Limpo e legível

---

## 3.2 Estrutura do Mundo

### Conceito: Mundo Aberto Evolutivo
- **Começa pequeno** (1 área)
- **Expande conforme fases são criadas**
- **Áreas conectadas** por passagens/portais
- **Acessibilidade**: Fácil de navegar, sem muito backtracking

### Possíveis Áreas (sugestão)
```
[Pátio Principal]
    ↓
[Sala de Aula] ← [Biblioteca]
    ↓
[Jardim Escolar]
    ↓
[Cantina] ← [Corredor]
```

### Limite Realista
**Até 4 de setembro**: ~3-4 áreas conectadas (MVP)  
**Se tiver tempo**: Mais áreas, mais detalhes

---

## 3.3 Elementos Visuais

### Paleta de Cores
| Elemento | Cor Primária | Cor Secundária |
|----------|-------------|-------------|
| Fundo | Azul claro / Verde | Branco |
| Plataformas | Marrom (madeira) | Cinza |
| Blocos números | Amarelo / Laranja | Dourado (brilho) |
| Galinha | Laranja/Vermelho | Preto |
| Texto | Preto | Branco |

### Estilo
- **Pixel Art** simples (recomendado) OU
- **2D Clean** (linhas simples, cores sólidas)
- **Resolução**: 320x180 ou 640x360 (escalável)

### Personagem Principal: Galinha
- ✅ Simples (pode começar com quadrado ou triângulo)
- ✅ Animada (2-3 frames pra walk)
- ✅ Expressiva (olhinhos, movimentos)
- ⚠️ **Tamanho**: ~32x32 ou ~16x16 pixels (se pixel art)

**Sprite Sheet Base**:
```
[Idle] [Walk1] [Walk2] [Jump] [Fall]
```

### Plataformas & Objetos
- Mesas (quadradas, simples)
- Livros empilhados (rampas)
- Cercas (paredes)
- Árvores (decoração + plataforma)
- Plantas (decoração)

### Blocos Numéricos
- **Forma**: Cubo/quadrado
- **Tamanho**: ~24x24 pixels
- **Números**: Fonte grande (18-20pt), bold
- **Cores**: Diferentes pra cada número (ou mesmo padrão com número em destaque)

**Exemplo**:
```
┌─────┐
│  3  │  ← Número grande, centralizado
└─────┘
```

---

## 3.4 Câmera

### Comportamento
- **Segue a galinha** sempre (com pequeno delay suave)
- **Mostra a conta no topo** (espaço reservado)
- **Zoom**: Mantém 1x (sem zoom dinâmico)

### Limites
- Não mostra fora do mundo (black bars nas bordas se necessário)
- Mínimo 200 pixels de altura visível (pra ver plataformas à frente)

---

## 3.5 Atmosfera & Imersão

### Áudio Ambiente (Opcional)
- Música de fundo calma (loops)
- Sons de pássaros / natureza
- Silêncio pode funcionar tb

### Iluminação
- Luz natural (dia claro)
- Sem sombras complexas
- Cores vibrantes mas não cansativas

---

## 3.6 Acessibilidade no Espaço

### Navegação
- Plataformas com altura progressiva (não muito diferença)
- Sem caminhos muito complexos
- Sempre visível a próxima plataforma

### Dicas Visuais
- Blocos brilham levemente (pra não se perderem)
- Plataformas com contraste claro do fundo
- Setas ou indicadores de direção (opcional)

---

## Links Relacionados
- [[01_Visao_Geral]] - Contexto geral
- [[02_Mecanicas_Principais]] - Como a galinha interage
- [[10_Recursos_Assets]] - Detalhes técnicos de sprites e assets
