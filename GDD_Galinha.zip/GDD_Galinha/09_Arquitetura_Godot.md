# 9️⃣ Arquitetura & Estrutura Técnica (Godot 4)

## 9.1 Estrutura de Pastas do Projeto

```
galinha_math_game/
├── scenes/
│   ├── main/
│   │   └── Main.tscn (cena raiz)
│   ├── player/
│   │   └── Player.tscn
│   ├── level/
│   │   └── Level.tscn (template pra cada fase)
│   ├── ui/
│   │   ├── Menu.tscn
│   │   ├── HUD.tscn
│   │   ├── GameOverScreen.tscn
│   │   └── PauseMenu.tscn
│   └── objects/
│       ├── Block.tscn
│       └── Platform.tscn
├── scripts/
│   ├── player.gd
│   ├── block_manager.gd
│   ├── math_system.gd
│   ├── level_manager.gd
│   ├── ui_manager.gd
│   └── game_manager.gd
├── assets/
│   ├── sprites/
│   │   ├── galinha_walk.png
│   │   ├── galinha_idle.png
│   │   ├── galinha_jump.png
│   │   ├── block_default.png
│   │   ├── tileset.png
│   │   └── background.png
│   ├── sounds/
│   │   ├── pickup_correct.wav
│   │   ├── pickup_wrong.wav
│   │   ├── victory.wav
│   │   └── music_loop.ogg
│   └── fonts/
│       └── arial_bold_24.tres
├── levels/
│   ├── level_1.tres (dados de fase)
│   ├── level_2.tres
│   └── level_3.tres
├── project.godot
└── README.md
```

---

## 9.2 Estrutura de Cenas Detalhada

### Main.tscn (Raiz)
```
Main (Node)
├── World (Node2D)
│   ├── TileMap (TileMap) - plataformas
│   ├── Background (Sprite2D) - fundo visual
│   ├── Galinha (CharacterBody2D) - player
│   │   ├── CollisionShape2D
│   │   ├── Sprite2D
│   │   ├── AnimationPlayer
│   │   └── player.gd (script)
│   ├── BlocksContainer (Node) - pai dos blocos
│   │   ├── Block (Area2D) - dinâmico x5
│   │   └── ... (mais blocos instanciados em runtime)
│   ├── Camera2D - segue galinha
│   └── Limites (Node) - paredes invisíveis (optional)
│       ├── LeftWall (Area2D)
│       ├── RightWall (Area2D)
│       └── DeadZone (Area2D) - cai e morre
├── UI (CanvasLayer) - sempre visível
│   ├── ContaLabel (Label) - "5 + 3 = ?"
│   ├── FaseLabel (Label) - "Fase 1/5"
│   ├── FeedbackLabel (Label) - "Correto!" ou "Errado!"
│   └── ui_manager.gd (script)
├── AudioManager (Node)
│   ├── AudioStreamPlayer (música)
│   ├── SFXPlayer (sons)
│   └── audio_manager.gd
└── GameManager (Node) - gerencia estado global
    └── game_manager.gd
```

### Player.tscn (Instância em Main)
```
Galinha (CharacterBody2D)
├── Sprite2D
│   └── Texture: galinha_spritesheet.png
│   └── HFrames: 4 (4 frames de animação)
├── CollisionShape2D
│   └── Shape: CapsuleShape2D (altura ~30px, largura ~20px)
├── AnimationPlayer
│   ├── Anim "idle" - frame 0
│   ├── Anim "walk" - frames 0-2 loop
│   └── Anim "jump" - frame 3
└── player.gd (script)
```

### Block.tscn (Template)
```
Block (Area2D)
├── CollisionShape2D
│   └── Shape: RectangleShape2D (24x24)
├── Sprite2D
│   └── Texture: block_default.png
├── Label (número)
│   └── Text: "3" (dinâmico)
│   └── Font: monospace bold
└── block.gd (script)
```

---

## 9.3 Scripts Principais

### player.gd
```gdscript
extends CharacterBody2D

const SPEED = 150.0
const JUMP_FORCE = -400.0
const GRAVITY = 800.0

var is_jumping = false

func _physics_process(delta):
    # Movimento horizontal
    var direction = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
    velocity.x = direction.x * SPEED
    
    # Pulo
    if Input.is_action_just_pressed("ui_accept") and is_on_floor():
        velocity.y = JUMP_FORCE
    
    # Gravidade
    if not is_on_floor():
        velocity.y += GRAVITY * delta
    
    # Atualizar posição
    move_and_slide()
    
    # Atualizar animação
    update_animation(direction)

func update_animation(direction):
    if direction.x != 0:
        $AnimationPlayer.play("walk")
    elif is_on_floor():
        $AnimationPlayer.play("idle")
    # jump animation automática no pulo
```

### math_system.gd
```gdscript
extends Node

var current_equation = {}
var correct_answer = 0

func generate_equation(level: int = 1):
    var a = randi() % 10  # 0-9
    var b = randi() % 10
    var operation = "+"
    
    # Progressão: nível 1-3 = adição, 4-6 = subtração, etc
    if level > 3:
        operation = "-"
    
    current_equation = {
        "a": a,
        "b": b,
        "operation": operation,
    }
    
    # Calcular resposta correta
    if operation == "+":
        correct_answer = a + b
    else:
        correct_answer = a - b
    
    return "%d %s %d = ?" % [a, operation, b]

func check_answer(value: int) -> bool:
    return value == correct_answer
```

### block_manager.gd
```gdscript
extends Node

const BLOCK_SCENE = preload("res://scenes/objects/Block.tscn")

@export var spawn_count = 5  # 5 blocos por fase
@export var spawn_area = Rect2(0, 0, 800, 600)

var blocks = []
var correct_block = null

func spawn_blocks(answer: int, wrong_answers: Array[int]):
    # Limpar blocos antigos
    for block in blocks:
        block.queue_free()
    blocks.clear()
    
    # Spawnar bloco correto em posição aleatória
    var correct_block_instance = BLOCK_SCENE.instantiate()
    correct_block_instance.set_number(answer)
    correct_block_instance.set_correct(true)
    add_child(correct_block_instance)
    blocks.append(correct_block_instance)
    
    # Spawnar blocos errados
    for wrong_answer in wrong_answers:
        var block_instance = BLOCK_SCENE.instantiate()
        block_instance.set_number(wrong_answer)
        block_instance.set_correct(false)
        add_child(block_instance)
        blocks.append(block_instance)
```

### level_manager.gd
```gdscript
extends Node

var current_level = 1
var total_levels = 5

var levels_data = [
    {"equation": "2+1", "answer": 3},
    {"equation": "3+2", "answer": 5},
    {"equation": "5-2", "answer": 3},
    # ... mais fases
]

func load_level(level_num: int):
    current_level = level_num
    if level_num >= total_levels:
        show_game_over_screen()
        return
    
    var level_data = levels_data[level_num - 1]
    var equation = MathSystem.generate_equation(level_num)
    
    $UI/ContaLabel.text = equation
    BlockManager.spawn_blocks(MathSystem.correct_answer, generate_wrong_answers())

func complete_level():
    current_level += 1
    load_level(current_level)

func generate_wrong_answers():
    var wrong = []
    for i in range(5):
        wrong.append((MathSystem.correct_answer + randi() % 5 - 2))
    return wrong
```

### block.gd
```gdscript
extends Area2D

var number = 0
var is_correct = false

func _ready():
    area_entered.connect(_on_area_entered)

func set_number(num: int):
    number = num
    $Label.text = str(num)

func set_correct(correct: bool):
    is_correct = correct
    # Mudar cor se correto/errado (visual opcional)
    if correct:
        modulate = Color.YELLOW
    else:
        modulate = Color.WHITE

func _on_area_entered(area):
    if area.is_in_group("player"):
        if is_correct:
            # Vitória!
            get_tree().get_first_node_in_group("game_manager").on_block_collected(number)
        else:
            # Erro!
            get_tree().get_first_node_in_group("game_manager").on_wrong_block(number)
        queue_free()
```

### ui_manager.gd
```gdscript
extends CanvasLayer

func update_equation_display(equation_text: String):
    $ContaLabel.text = equation_text

func show_feedback(is_correct: bool):
    if is_correct:
        $FeedbackLabel.text = "✅ Correto!"
        $FeedbackLabel.add_theme_color_override("font_color", Color.GREEN)
    else:
        $FeedbackLabel.text = "❌ Errado!"
        $FeedbackLabel.add_theme_color_override("font_color", Color.RED)
    
    $FeedbackLabel.show()
    await get_tree().create_timer(1.0).timeout
    $FeedbackLabel.hide()
```

---

## 9.4 Signals (Sinais) Godot

```gdscript
# Em GameManager ou Level Manager
signal level_started(level_num)
signal level_completed(level_num)
signal block_collected(number, is_correct)
signal player_died
signal game_over_all_levels

# Uso:
level_completed.emit(1)
block_collected.emit(5, true)
```

---

## 9.5 Configuração de Input Map

**Project → Project Settings → Input Map**

```
ui_left: A, Left Arrow
ui_right: D, Right Arrow
ui_accept: Space (pulo)
ui_cancel: ESC (pausa)
```

---

## 9.6 Importação de Assets

### Sprites
1. Colocar `.png` em `assets/sprites/`
2. Godot importa automaticamente
3. No Sprite2D, arrastar arquivo pra `Texture`
4. Ajustar `Hframes` e `Vframes` pro spritesheet

### Áudio
1. Colocar `.wav` ou `.ogg` em `assets/sounds/`
2. No AudioStreamPlayer, arrastar pra `Stream`
3. Configurar `volume_db` (-20 pra sons, -10 pra música)

### Fontes
1. Colocar `.ttf` em `assets/fonts/`
2. Criar `.tres` (Theme Resource) com fonte customizada
3. Aplicar no Label via `Custom Fonts`

---

## 9.7 Build & Export

### Testar Localmente
```bash
# Abrir projeto
cd galinha_math_game/
godot --path . 2d.opengl3
```

### Build Windows (.exe)
1. **Project → Export** 
2. **Add Preset → Windows Desktop**
3. **Release** (não Debug, é maior)
4. Escolher pasta de saída
5. **Export**

### Build Linux
```bash
Mesmo processo, mas preset Linux
```

---

## 9.8 Autosave & Versionamento

### Git (.gitignore)
```
# Adicionar ao .gitignore
.godot/
*.import
user/
.env
*.exe
*.pck
```

### Commits Recomendados
```bash
git add scenes/ scripts/ assets/
git commit -m "Feat: Player movement e camera"
git commit -m "Feat: Math system funcionando"
git commit -m "Fix: Physics bug pulo"
git commit -m "Polish: UI final"
```

---

## 9.9 Performance & Otimização

### Dicas Básicas
- ✅ Usar Sprites simples (não texturas 4K)
- ✅ Limitar quantidade de blocos (5-7 max)
- ✅ Usar CanvasLayer pra UI (não fica no mundo)
- ✅ Limpar scenes (queue_free ao mudar fase)
- ⚠️ Evitar physics complexa (simples = melhor)

### Debug
- F5 = Play
- F6 = Play scene (cena atual)
- `print()` pra testar valores
- Debugger integrado (F7)

---

## 9.10 Checklist Técnico

### Antes de Entregar
- [ ] Projeto abre sem erros no Godot 4
- [ ] Sem crashes ao rodar
- [ ] Todas as cenas linkadas corretamente
- [ ] Sem nodes órfãos (detached)
- [ ] Scripts comentados (principalmente lógica complexa)
- [ ] Assets importados corretamente
- [ ] Build testada (.exe funciona)
- [ ] Git com commits lógicos

---

## Links Relacionados
- [[08_Divisao_Tarefas]] - Quem implementa o quê
- [[06_Escopo_MVP]] - O que implementar primeiro
- [[07_Cronograma]] - Quando fazer cada script
