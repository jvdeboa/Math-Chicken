# 6️⃣ Escopo: O Que Fazer Até 4 de Setembro

## ✅ MVP (Mínimo Viável) - OBRIGATÓRIO

**Tempo necessário: ~16-20 horas (2-3 semanas de 6h/semana)**

### Godot Setup & Fundação
- [ ] Cena base do mundo
- [ ] Player (galinha) com movimento esquerda/direita
- [ ] Pulo funcional (gravidade, detecção de solo)
- [ ] Plataformas básicas (TileMap ou RigidBody2D)
- [ ] Câmera seguindo jogador
- [ ] Animações básicas (idle, walk, jump)

### Sistema de Contas
- [ ] Gerador de contas simples (adição básica)
- [ ] Label mostrando conta na tela
- [ ] Verificação se bloco pegado == resposta
- [ ] Estrutura pra diferentes tipos de contas

### Blocos Numéricos
- [ ] Spawn de blocos aleatoriamente em cada fase
- [ ] Blocos flutuam (animação suave de bobbing)
- [ ] Colisão com player detecta corretamente
- [ ] Visual claro (número grande, fácil ler)
- [ ] Feedback ao pegar (som + animação)

### Fases & Progressão
- [ ] **Mínimo 3-5 fases funcionais**
- [ ] Cada fase tem conta diferente
- [ ] Transição entre fases (fade ou similar)
- [ ] Progressão de dificuldade (primeiro blocos mais perto, depois mais espalhados)
- [ ] Menu pra ir pra próxima fase ou retry

### UI/HUD
- [ ] Menu inicial simples (Jogar, Sair)
- [ ] HUD mostrando conta durante gameplay
- [ ] Tela de vitória de fase (Próxima/Retry/Menu)
- [ ] Feedback claro: acertou vs errou

### Outros Essenciais
- [ ] Sem crashes graves
- [ ] Sem bugs de física bloqueantes
- [ ] Código comentado (principais scripts)
- [ ] Funcionar do início até fim sem reset manual

---

## 🎯 DESEJÁVEL - Se tempo permitir (+5-10 horas)

- [ ] 8-10 fases completas (não só 3-5)
- [ ] **Subtração** além de adição
- [ ] Mundo um pouco maior/mais polido
  - [ ] 2-3 áreas conectadas
  - [ ] Sprites um pouco mais detalhados
- [ ] Alguns obstáculos móveis (plataforma que sai/volta)
- [ ] Sons simples (pega bloco, vitória, erro)
- [ ] Música de fundo (loop suave)
- [ ] Pausa funcional (ESC)
- [ ] Menu de instruções

---

## 💎 BÔNUS - Se MUUUITO tempo sobrar (+5-10 horas)

- [ ] Multiplicação/Divisão
- [ ] Mais biomas do mundo (3-5 áreas polidas)
- [ ] Inimigos simples (patrulham e retornam ao início se tocar)
- [ ] Animações mais polidas (pulo duplo, dash)
- [ ] Sistema de pontuação (bonus por tempo rápido)
- [ ] Tela de configurações (volume, etc.)
- [ ] Mais de 15 fases
- [ ] Créditos legais
- [ ] Efeitos de partículas (explosão ao completar fase)

---

## 📊 Tabela de Prioridade

| Item | MVP | Desejável | Bônus | Horas Est. |
|------|-----|-----------|-------|-----------|
| Setup Godot | ✅ | | | 2 |
| Movement + Pulo | ✅ | | | 3 |
| Sistema Contas | ✅ | | | 2 |
| Blocos | ✅ | | | 3 |
| 3-5 Fases | ✅ | | | 4 |
| Adição | ✅ | | | (incluído) |
| Subtração | | ✅ | | 2 |
| 8-10 Fases | | ✅ | | 4 |
| Mundo polido | | ✅ | | 3 |
| Sons/Música | | ✅ | | 2 |
| Obstáculos | | ✅ | | 2 |
| Multiplicação | | | ✅ | 2 |
| Mais biomas | | | ✅ | 3 |
| Inimigos | | | ✅ | 3 |
| Polish visual | | | ✅ | 2 |
| **TOTAL MVP** | | | | **~18-20h** |

---

## 🎮 Checklist de Entrega Final

Antes de submeter, certificar-se que tem:

### Funcionalidade
- [ ] Jogo abre sem crashes
- [ ] Menu funciona (jogar, sair)
- [ ] Todas as fases abrem
- [ ] Jogador consegue completar TODAS as fases
- [ ] Conta aparece correta em cada fase
- [ ] Blocos aparecem aleatoriamente
- [ ] Verificação de resposta funciona
- [ ] Transição entre fases OK

### Qualidade
- [ ] Sem bugs críticos (physics travando, UI invisível, etc.)
- [ ] Sem lag excessivo (60fps ou próximo)
- [ ] Feedback claro (som ou visual ao acertar/errar)
- [ ] Controles responsivos (sem delay)

### Documentação
- [ ] Este GDD completo
- [ ] Código dos scripts principais comentado
- [ ] README.md explicando como jogar
- [ ] Arquivo .exe ou instrução pra rodar

### Apresentação (Escolar)
- [ ] Video curto gameplay (30-60s)
- [ ] Screenshots de 2-3 fases diferentes
- [ ] Breve relato: o que funcionou, o que foi desafio

---

## ⚠️ Escape Hatches (Se faltar tempo)

Se chegou final de agosto e ainda não tem 3 fases prontas:

1. **Reduzir visual**
   - Remover animações complexas
   - Usar cores sólidas no lugar de sprites
   - Simplificar tileset

2. **Reduzir conteúdo**
   - 3 fases ao invés de 5-10
   - Só adição, sem subtração
   - 1 área do mundo ao invés de 3

3. **Reduzir áudio**
   - Remover música
   - Só beeps simples (Godot AudioStreamPlayer)

4. **Priorizar funcionalidade**
   - Jogo 100% funcional com 3 fases > 10 fases bugadas
   - Melhor um MVP sólido

---

## Links Relacionados
- [[07_Cronograma]] - Quando fazer cada coisa
- [[08_Divisao_Tarefas]] - Quem faz o quê
- [[02_Mecanicas_Principais]] - Entender o que é MVP
