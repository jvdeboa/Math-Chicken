# 4️⃣ UI/UX

## 4.1 HUD (Heads-Up Display)

### Conta Atual
- **Posição**: Topo/centro da tela
- **Tamanho**: Grande e bem legível (40-50pt)
- **Formato**: `5 + 3 = ?`
- **Fundo**: Leve (semi-transparente branco/cinza)
- **Exemplo Visual**:
```
╔═════════════════╗
║   5 + 3 = ?     ║
╚═════════════════╝
```

### Número de Fases Completadas
- **Posição**: Canto superior esquerdo ou direito
- **Formato**: `Fase: 3/10` ou `Progress: ▓▓▓░░░░░░░` (barra)
- **Tamanho**: Pequeno (16-20pt)
- **Atualiza**: Ao completar cada fase

### Vidas/Tentativas (Se implementado)
- **Posição**: Canto esquerdo ou direito (oposto do progresso)
- **Visual**: ❤️❤️❤️ (corações) ou ⭐⭐⭐ (estrelas)
- **Atualiza**: Ao cometer erro

---

## 4.2 Feedback Visual

### Ao Pegar Bloco Correto
- Bloco **brilha intensamente** (animação de 0.3s)
- Texto "Correto!" ou ✅ aparece brevemente
- **Transição suave** pra próxima fase

### Ao Pegar Bloco Errado
- Tela **pisca vermelho** (0.2s)
- Bloco **desaparece** ou fica **acinzentado**
- Texto "Errado!" ou ❌ aparece
- Retorna ao início da fase após 1s

### Ao Completar Fase
- Galinha **pula de alegria** (animação)
- Texto "Fase Completa!" aparece
- **Transição** pra próxima fase (fade ou deslizar)

---

## 4.3 Menus

### Menu Inicial
```
┌─────────────────┐
│  🐔 GALINHA     │
│  MATEMÁTICA     │
│                 │
│  [JOGAR]        │
│  [INSTRUÇÕES]   │
│  [CRÉDITOS]     │
│  [SAIR]         │
└─────────────────┘
```

- **Título**: Grande e colorido
- **Botões**: Simples, com hover (mudam cor)
- **Fundo**: Imagem da escola ou cor sólida

### Menu de Pausa
```
┌─────────────────┐
│  ⏸️ PAUSADO     │
│                 │
│  [CONTINUAR]    │
│  [MENU INICIAL] │
│  [SAIR]         │
└─────────────────┘
```

- **Overlay semi-transparente** no fundo
- **Efeito blur** opcional (suave)
- **Atalho**: ESC pra pausar/despausar

### Tela de Vitória (Fim de Fase)
```
┌─────────────────┐
│  ✅ FASE 3      │
│  COMPLETADA!    │
│                 │
│  Pontos: 1000   │
│                 │
│  [PRÓXIMA FASE] │
│  [RETRY]        │
│  [MENU]         │
└─────────────────┘
```

- Mostra número da fase
- **Pontuação** (opcional, baseada em tempo?)
- Três opções de ação

### Tela de Game Over (Se falhar fase)
```
┌─────────────────┐
│  ❌ GAME OVER   │
│                 │
│  Tentativa: 3/5 │
│                 │
│  [RETRY]        │
│  [MENU INICIAL] │
└─────────────────┘
```

- Mostra número de tentativas (se houver limite)
- Encoraja retry
- Volta ao menu como opção

### Tela de Fim (Final do Jogo)
```
┌─────────────────┐
│  🎉 PARABÉNS!   │
│                 │
│  Você completou │
│  todas as fases!│
│                 │
│  Total de fases:│
│  15             │
│                 │
│  [MENU INICIAL] │
│  [CRÉDITOS]     │
└─────────────────┘
```

---

## 4.4 Feedback Sonoro

### Efeitos Sonoros
| Evento | Som | Duração |
|--------|-----|---------|
| Pega bloco correto | Ding/Chime alegre | 0.5s |
| Pega bloco errado | Buzzer/Erro | 0.3s |
| Completa fase | Fanfarra curta | 1s |
| Pulo | Whoosh suave | 0.2s |
| Pausa | Click | 0.1s |

### Música de Fundo
- **Menu**: Tema calmo e welcoming
- **Gameplay**: Loop médio (não repetitivo)
- **Vitória**: Tema alegre (curto)
- **Game Over**: Tema triste (curto)

### Volume
- SFX: Ligeiramente maior que música (proporção 80/100 vs 60/100)
- Controle de volume no menu (opcional)

---

## 4.5 Animações UI

### Transição Entre Telas
- **Fade in/out**: 0.3-0.5s
- **Suave**: Sem pulos abruptos
- **Rápida**: Não demora

### Animações de Texto
- Labels piscam ao aparecer (suave)
- Ícones giram levemente (opcional)
- Botões crescem ao passar mouse (hover)

### Animações de Feedback
- Números flutuam levemente (bobbing)
- Brilhos pulsam (não muito rápido)
- Transições suaves entre cores

---

## 4.6 Acessibilidade

### Tamanho de Texto
- **Mínimo 16pt**: Legível em telas pequenas
- **Conta**: 40-50pt (bem grande)
- **Títulos menus**: 36pt

### Contraste
- Texto preto em fundo branco/claro (ou vice-versa)
- Sem cores muito similares lado a lado
- Sem apenas cor como indicador (usar ícone + cor)

### Cores
- ✅ Verde pra sucesso, ❌ Vermelho pra erro (mas não só essas cores)
- Considerar daltonismo (evitar apenas vermelho/verde)

---

## Links Relacionados
- [[02_Mecanicas_Principais]] - Feedback da mecânica
- [[05_Fluxo_Gameplay]] - Como os menus se conectam
- [[09_Arquitetura_Godot]] - Implementação técnica
