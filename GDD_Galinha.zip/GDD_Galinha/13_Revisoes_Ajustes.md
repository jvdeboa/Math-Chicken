# 1️⃣3️⃣ Revisões & Ajustes Durante Desenvolvimento

## 📋 Mudanças Realizadas

Use este espaço pra anotar **qualquer coisa que mudou** do GDD original durante o desenvolvimento.

### Formato:
```
**Data** | **O que mudou** | **Por quê** | **Impacto**
```

---

## Semana 1

### Terça [__/__]
- [ ] **Mudança**: 
  **Por quê**: 
  **Impacto**: 

- [ ] **Mudança**: 
  **Por quê**: 
  **Impacto**: 

### Sexta [__/__]
- [ ] **Mudança**: 
  **Por quê**: 
  **Impacto**: 

---

## Semana 2

### Terça [__/__]
- [ ] **Mudança**: 
  **Por quê**: 
  **Impacto**: 

### Sexta [__/__]
- [ ] **Mudança**: 
  **Por quê**: 
  **Impacto**: 

---

## Semana 3

### Terça [__/__]
- [ ] **Mudança**: 
  **Por quê**: 
  **Impacto**: 

### Sexta [__/__]
- [ ] **Mudança**: 
  **Por quê**: 
  **Impacto**: 

---

## 📝 Exemplos de Mudanças Comuns

### Escopo
- "Reduzido de 10 fases pra 5 (falta de tempo)"
- "Adicionado mundo com múltiplas áreas (era só uma)"
- "Removido sistema de vidas (muito complexo)"

### Mecânicas
- "Blocos agora têm gravidade (antes flutuavam)"
- "Galinha pode fazer duplo pulo (era só simples)"
- "Adicionado inimigos patrulhando (novo desafio)"

### Visual
- "Mudado de pixel art pra 2D clean (mais rápido)"
- "Sprites reduzidas de 64x64 pra 32x32 (performance)"
- "Paleta de cores simplificada (2 cores por sprite)"

### Audio
- "Removido música (falta de tempo)"
- "Sons reduzidos pra beeps simples (mais fácil)"
- "Adicionado efeitos visuais ao invés de som"

### Técnico
- "Mudado Physics CharacterBody2D pra RigidBody2D (mais simples)"
- "Fases agora com dados em JSON (era hardcoded)"
- "Adicionado sistema de save (bom pra testing)"

---

## ⚠️ Mudanças Que Afetam Entrega

Alguns ajustes podem impactar a avaliação. Documente especialmente:

### Simplificações (Escopo Reduzido)
Se teve que simplificar o que foi apresentado inicialmente:

**Exemplo**:
> **O que foi**: 10 fases com multiplicação/divisão
> **O que ficou**: 5 fases só adição/subtração
> **Por quê**: Falta de tempo para desenvolvimento
> **Data da mudança**: 28 de agosto

### Mudanças Mecânicas
Se a mecânica core mudou:

**Exemplo**:
> **O que foi**: Blocos flutuavam aleatoriamente
> **O que ficou**: Blocos fixos em plataformas
> **Por quê**: Colisão mais simples, menos bugs
> **Data**: 29 de agosto

### Recursos Removidos
Se removeu algo importante:

**Exemplo**:
> **O que foi**: Múltiplos biomas (pátio, sala, jardim)
> **O que ficou**: Um bioma (pátio escolar)
> **Por quê**: Art seria muito trabalho
> **Data**: 1 de setembro

---

## 🚀 Melhorias Implementadas

Às vezes você consegue adicionar coisas **MELHORES** que o planejado:

**Exemplo**:
> **Melhoria**: Sistema de pontuação por velocidade
> **Justificativa**: Motivou players a fazer fases rápido
> **Impacto Positivo**: Engagement aumentou
> **Data**: 2 de setembro

---

## 🐛 Bugs Encontrados & Resolvidos

Documente bugs importantes encontrados:

| Bug | Sintoma | Solução | Resolvido em |
|-----|---------|---------|-------------|
| Galinha cai infinito | Gravity loop | Ajustar gravidade | Semana 1, Sexta |
| Bloco não pega | Area2D sem collision | Adicionar CollisionShape2D | Semana 2, Terça |
| Menu não abre | Cena não existe | Criar Scene Menu.tscn | Semana 2, Sexta |

---

## 📊 Comparação: Planejado vs Realizado

**Preencher ao final do projeto**:

| Aspecto | Planejado | Realizado | Diferença |
|---------|-----------|-----------|-----------|
| Fases | 10 | _ | |
| Operações (Adição/Sub/Mult) | Todas 3 | _ | |
| Áreas do Mundo | 3 | _ | |
| Sons SFX | 5 | _ | |
| Animações | Caminhada, Pulo | _ | |
| Horas Gastas | 18 | _ | |

---

## 🎯 Decisões Importantes Tomadas

**Data** | **Decisão** | **Votação** | **Resultado**
--- | --- | --- | ---
[__/__] | Use Krita ao invés de Aseprite | Pessoa A: Sim, Pessoa B: Não | Krita (mais barato) |
[__/__] | Remover sistema de vidas | Ambos: Sim | Removido |
[__/__] | Adicionar mundo aberto vs linear | A: Aberto, B: Linear | Linear (mais simples) |

---

## 📈 Lições Aprendidas

**Espaço pra anotar o que aprendeu**:

### Técnico
- [ ] Godot é melhor/pior que esperava porque...
- [ ] GDScript foi fácil/difícil porque...
- [ ] Physics é tricky porque...

### Design
- [ ] Progressão de dificuldade...
- [ ] Feedback foi importante porque...
- [ ] Escopo foi realista/otimista porque...

### Processo
- [ ] Trabalho em dupla foi bom/desafiador porque...
- [ ] Comunicação precisaria melhorar em...
- [ ] Cronograma foi apertado/flexível porque...

---

## 💬 Feedback Recebido

### Durante Desenvolvimento
- [ ] Professora/Professor comentário: _______________
- [ ] Colega testador comentário: _______________
- [ ] Auto-crítica: _______________

### Após Entrega (Se houver)
- [ ] Avaliação: _______________
- [ ] Feedback: _______________
- [ ] Nota: _______________

---

## ✅ Checklist Final de Mudanças

Antes de entregar, responda:
- [ ] Todas as mudanças foram documentadas aqui?
- [ ] As mudanças impactam a avaliação negativamente?
- [ ] Tenho justificativas pras mudanças?
- [ ] Comparado com o GDD original, está claro o que mudou?

---

## 📄 Modelo de Apresentação das Mudanças

**Se tiver que explicar pra professora:**

```
Olá,

Durante o desenvolvimento, fizemos as seguintes mudanças 
do plano original:

1. ESCOPO: Reduzido de 10 pra 5 fases
   - Motivo: Falta de tempo para arte
   - Impacto: Jogo menor, mas 100% funcional

2. MECÂNICAS: Blocos agora em plataformas (não flutuam)
   - Motivo: Mais simples de debugar
   - Impacto: Menos fases, mas gameplay mais sólido

3. VISUAL: Pixel art 32x32 (foi planejado 64x64)
   - Motivo: Performance
   - Impacto: Jogo mais rápido, sem lag

Resultado Final: MVP 100% funcional com 5 fases.
Todas as mudanças foram necessárias e justificadas.

Obrigado,
[Equipe]
```

---

## Links Relacionados
- [[06_Escopo_MVP]] - Escopo original
- [[07_Cronograma]] - Timeline original
- [[12_Notas_Importantes]] - Planos B e soluções
