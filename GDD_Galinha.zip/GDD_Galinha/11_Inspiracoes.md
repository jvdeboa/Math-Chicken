# 1️⃣1️⃣ Inspirações & Referências

## 11.1 Jogos de Referência

### Mechanics Platformer

#### **Flappy Bird**
- ✅ O quê aprender: Simplicidade extrema
- Mecânica: 1 botão (tap/espaço), pulo contínuo
- Visual: Minimalista, cores vibrantes
- Educação indireta: Timing, reflexo
- **Relevância**: Temos pulo + timing também

#### **Celeste**
- ✅ O quê aprender: Progressão de dificuldade clara
- Mecânica: Pulo, dash, paredes
- Visual: Pixel art lindo (referência)
- Áudio: Sons satisfying (muito bom)
- **Relevância**: Ambos progridem em dificuldade

#### **Super Meat Boy**
- ✅ O quê aprender: Feedback satisfying no pulo
- Mecânica: Pulo rápido, preciso, checkpoints
- Visual: Sprite grande, cores contrastantes
- **Relevância**: Pulo é core mechanic

#### **Sonic**
- ✅ O quê aprender: Movimentação suave
- Mecânica: Correr contínuo + inércia
- Visual: Personagem expressivo
- **Relevância**: Personagem (galinha) precisa ter personalidade

---

### Math-based/Puzzle Platformer

#### **Brain Training by Dr. Kawashima** (Nintendo)
- ✅ O quê aprender: Educação com jogabilidade
- Mecânica: Mini-games de matemática
- Feedback: Scorecard, progressão
- **Relevância**: Combina math + gameplay (direto)

#### **Duolingo**
- ✅ O quê aprender: Gamificação educativa indireita
- Mecânica: Streak, XP, levels
- Visual: Personagem mascot (Duo)
- **Relevância**: Visual amigável, progressão clara

#### **Portal**
- ✅ O quê aprender: Puzzle + movimento
- Mecânica: Pensamento espacial integrado à action
- **Relevância**: Blocos/contas são "puzzle" do nosso jogo

---

### Visual Style

#### **Stardew Valley**
- Pixel art suave
- Cores pastel
- Tiled mundo
- Personagens expressivos

#### **Hollow Knight**
- Pixel art preto/branco + cor
- Atmosfera leve
- Sprites elegantes
- Enemy design claro

#### **Minit**
- Ultra minimalista
- Formas geométricas
- Cores 2-3 apenas
- Estilo limpo

---

## 11.2 Recursos de Referência

### Design
- **Game Design Workshop** (Tracy Fullerton) - Livro clássico
- **MDA Framework** - Mechanics, Dynamics, Aesthetics
- **GDD Templates** - Há muitos online

### Godot Específico
- **Brackeys** (YouTube) - Tutoriais Godot (mesmo antigos, úteis)
- **Heartbeast** (YouTube) - Pixel art platformer no Godot
- **Guru's Lair** (YouTube) - Tutoriais de física/movement
- **Dokumentasi Godot** - Oficial (em português tem!)

### Matemática em Jogos
- **Wired Brains Courses** - Game Math
- **Game Maker's Toolkit** - Game Design analysis
- **GDC Talks** - Game Developer Conference videos

---

## 11.3 Comparação: O Que Funcionou em Referências

| Jogo | Mecânica Core | Por que funciona | Aplicar ao nosso? |
|------|------|---------|----------|
| Flappy Bird | 1 input | Simplicidade pura | Sim - um input (pulo) |
| Celeste | Movimento + Mecânica | Progressão clara | Sim - fases aumentam |
| Mario | Pulo + timing | Feedback satisfying | Sim - base de platformer |
| Duolingo | Gamificação + visual | Motivação | Sim - visual amigável |
| Portal | Spatial reasoning | Puzzle integrado | Talvez - contas como "puzzle" |

---

## 11.4 Estudo de Caso: "Como Ensinar sem Parecer Ensino"

### Duolingo (Educação Indireta)
**Como funciona**:
1. Jogador quer passar de nível
2. Precisa responder perguntas de idioma
3. Aprende sem perceber

**Aplicar ao nosso**:
1. Jogador quer completar fase
2. Precisa pegar bloco com resposta correta
3. Pratica math sem parecer aula

### Portal (Pensamento Espacial)
**Como funciona**:
1. Mecânica de portal é simples
2. Puzzle usa pensamento 3D
3. Aprender geometria naturalmente

**Aplicar ao nosso**:
1. Mecânica de pegar bloco é simples
2. Contas usam lógica numérica
3. Aprender cálculo naturalmente

---

## 11.5 Paleta de Cores: Inspirações

### Estilo 1: Vibrante (Como Duolingo)
```
Background: #FFE5B4 (Pêssego suave)
Primário:   #FF6B35 (Laranja brilhante)
Secundário: #F7931E (Dourado)
Acento:     #06D6A0 (Verde neon suave)
```

### Estilo 2: Pixel Art Retro (Como NES)
```
Background: #4A69BD (Azul claro)
Primário:   #D32F2F (Vermelho pixel)
Secundário: #FFD700 (Amarelo)
Acento:     #7CB342 (Verde)
```

### Estilo 3: Minimalista (Como Flappy Bird)
```
Background: #87CEEB (Azul céu)
Primário:   #FF0000 (Vermelho puro)
Secundário: #FFD700 (Amarelo)
Acento:     #000000 (Preto)
```

---

## 11.6 Sound Design: O Que Funciona

### Satisfying Sounds
- **Pega bloco correto**: Sine wave 800Hz (ding agudo)
- **Pula**: Whoosh reverb suave
- **Vitória**: Fanfarra baseada em tons maiores
- **Erro**: Buzzer descending

### Refs de Áudio
- **Portal**: Sons de feedback limpíssimos
- **Celeste**: Música e SFX bem sincronizados
- **Flappy Bird**: Beep simples mas satisfying

---

## 11.7 Estrutura Narrativa (Opcional)

Se quiser dar contexto:

### Simples
**Intro**: "Ajude a Galinha Gigi a completar os desafios da Escola!"

### Mais Detalhado
```
A Galinha Gigi está na escola e precisa resolver
desafios matemáticos pra ajudar seu professor!
Pegue os números certos pra completar as contas!
```

### Bem Expandido
```
Fase 1: "Quantos livros tem na mesa?"
Fase 2: "Quanto é 3 + 2?"
...
Final: "Parabéns! Você ajudou Gigi a passar em todos os testes!"
```

**Nossa recomendação**: Simples é melhor (foco no gameplay)

---

## 11.8 Melhores Práticas de Feedback

### O Que Funciona (Refs de Jogos Bons)
✅ Feedback imediato (< 200ms)
✅ Múltiplos canais (som + visual + haptic)
✅ Satisfação progressiva (vitória > pulo > movimento)
✅ Punição suave (volta início, não game over imediato)

### O Que NÃO Funciona
❌ Sem feedback (jogador não sabe se acertou)
❌ Feedback atrasado (frustrante)
❌ Feedback muito forte (cansativo)
❌ Punição dura demais (desestimulante)

---

## 11.9 Progressão de Dificuldade: Lições

### Curva de Dificuldade Ideal
```
Fase 1  *
Fase 2   *
Fase 3    **
Fase 4     **
Fase 5      ***  ← Sweet spot
Fase 6       ***
Fase 7        ****
Fase 8         ****
Fase 9          ****
Fase 10          *
```

**Regra**: Leve aumento, não salto brusco

**Aplicar**:
- Fases 1-3: Adição 1-5
- Fases 4-6: Adição 5-10 + Subtração simples
- Fases 7+: Misto, números maiores

---

## 11.10 Conclusão: Resumo de Inspirações

| Aspecto | Inspiração | Aplicação |
|---------|-----------|-----------|
| Mecânica | Flappy Bird, Mario | Pulo + Timing |
| Progressão | Celeste, Duolingo | Fases crescentes |
| Visual | Hollow Knight, Stardew | Pixel art limpo |
| Audio | Portal, Celeste | Feedback satisfying |
| Educação | Duolingo, Brain Training | Indireta, natural |
| Jogabilidade | Flappy Bird | Simples, acessível |

**O grande lema**: **Simples, satisfying, progressivo** ✨

---

## Links Relacionados
- [[03_Mundo_Ambientacao]] - Visual do jogo
- [[04_UI_UX]] - Feedback visual/áudio
- [[02_Mecanicas_Principais]] - Mecânicas inspiradas
