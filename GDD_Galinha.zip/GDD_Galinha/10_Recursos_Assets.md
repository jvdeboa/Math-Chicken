# 🔟 Recursos & Assets

## 10.1 Sprites & Visual Assets

### Galinha (Personagem Principal)

**Specs**:
- Tamanho: 32x32 pixels (pixel art) ou 64x64 (resolução maior)
- Frames necessários: 4-5
  - Idle (parado)
  - Walk (2-3 frames de locomoção)
  - Jump (no ar)
  - Fall (opcional, caindo)
- Formato: PNG com transparência
- Estilo: Pixel art simples, personagem

**Visual**:
- Cor primária: Laranja/Vermelho
- Olhos simples (2 pontinhos)
- Asas/corpo galinha reconhecível
- Expressão amigável

**Spritesheet Layout**:
```
[Idle] [Walk1] [Walk2] [Jump] [Fall]
32px   32px    32px    32px   32px
```

**Onde conseguir**:
- ✏️ **Desenhar**: Aseprite, Krita, Paint
- 🆓 **Asset Free**: OpenGameArt, itch.io/assets
- 🤖 **AI**: Stable Diffusion, Midjourney (depois pixelar)

---

### Blocos Numéricos

**Specs**:
- Tamanho: 24x24 ou 32x32 pixels
- Formato: Quadrado/Cubo simples
- Cor: Amarelo, Laranja ou Branco (com número preto)
- Tipo: Sprite estático (não animado) OU animação de bobbing

**Visual**:
```
┌──────────┐
│          │
│    3     │ ← Número grande, legível (14-18pt)
│          │
└──────────┘
```

- Sem sombras complexas
- Número centralizado
- Se quiser brilho: versão "iluminada" num segundo sprite

**Onde conseguir**:
- ✏️ Desenhar quadrado com número
- 🎨 Simple shapes + Godot renderiza número via Label

---

### Tileset & Plataformas

**Specs**:
- Tamanho de tile: 32x32 ou 16x16 pixels
- Cores: Marrom (madeira), cinza (pedra), verde (grama)
- Quantidade: 10-15 tiles diferentes
  - Plataforma reta
  - Canto esquerdo/direito
  - Ramp (rampa)
  - Decoração (grama, folhas)

**Tipos de Plataformas**:
| Tipo | Visual | Uso |
|------|--------|-----|
| Base | Madeira lisa | Chão básico |
| Ramp | Inclinada 45° | Subir ladeira |
| Thin | Fina | Desafio precisão |
| Cloud | Nuvem | Estética |
| Grass | Com grama | Decoração |

**Spritesheet Tileset**:
```
[Base]  [Ramp L] [Ramp R]
[Thin]  [Cloud]  [Deco]
...
```

**Onde conseguir**:
- ✏️ Desenhar grid simples
- 🆓 OpenGameArt, Kenney.nl (excelente gratuito)
- 🎮 Craft cores: arte simples mas profissional

---

### Background

**Specs**:
- Tamanho: Largura = 1280px (ou próximo a resolução)
- Altura: 720px (ou 16:9 do esperado)
- Formato: PNG
- Estilo: Céu, natureza (pátio escola)

**Visual**:
- Céu azul claro
- Pátio com grama
- Prédio escolar ao fundo (simples)
- Árvores, plantas (decoração)

**Exemplo Layout**:
```
[Céu azul]
[Pátio (grama verde)]
[Prédio distante (cinza/vermelho)]
```

---

## 10.2 Sons & Áudio

### Efeitos Sonoros (SFX)

| Evento | Som | Duração | Formato |
|--------|-----|---------|---------|
| Pega bloco correto | Ding/Chime | 0.3-0.5s | .wav |
| Pega bloco errado | Buzzer/Erro | 0.2-0.3s | .wav |
| Completa fase | Fanfarra | 0.8-1.0s | .wav |
| Pulo | Whoosh suave | 0.1-0.2s | .wav |
| Pausa | Click | 0.05s | .wav |

**Qualidade**:
- 44100 Hz (CD quality)
- Mono ou Stereo
- -3dB a -6dB (não muito alto)

**Onde conseguir**:
- 🔊 **Freesound.com**: Procurar "chime correct", "buzzer error"
- 🎵 **Zapsplat**: Efeitos simples gratuitos
- 🤖 **Gerador**: Bfxr (retro), Jsfxr (online)
- ✏️ **Gravar**: Própria voz (se criativo)

**Exemplo Bfxr**:
```
// Chime correto
- Coin: ding
- Volume: 80%

// Buzzer erro
- Laser: bzzzzt
- Volume: 60%
```

---

### Música de Fundo

| Cena | Estilo | Duração | BPM |
|------|--------|---------|-----|
| Menu | Calma, welcoming | Loop | 90-100 |
| Gameplay | Neutra, não distrai | Loop | 100-120 |
| Vitória | Alegre, celebração | 1-2s | 120+ |

**Qualidade**:
- 44100 Hz (ou 48000)
- Mono (economiza espaço)
- Loop perfeito (sem click no final)

**Onde conseguir**:
- 🎵 **OpenGameArt**: Procurar "platformer music"
- 🎶 **Incompetech**: Chris Zabriske (excelente, free)
- 🤖 **Gerador AI**: Jukebox AI, MuseNet
- 🎹 **Compositor**: GarageBand, FL Studio (versão trial)

---

## 10.3 Fontes

### Conta na Tela (HUD)

**Specs**:
- Tamanho: 36-48pt
- Estilo: Monospace ou Sans-serif bold
- Legibilidade: Máxima (sem fontes estranhas)
- Cor: Preto (ou branco se fundo escuro)

**Opções**:
- **Godot Default**: Arial (funciona bem)
- **Google Fonts** (free):
  - Roboto Mono (ótima)
  - JetBrains Mono (programador, legal)
  - Courier Prime (clássica)
- **Arquivo**: `.ttf` em `assets/fonts/`

**Como integrar**:
1. Baixar `.ttf` de Google Fonts
2. Colocar em `assets/fonts/`
3. Em Godot: Label → Custom Fonts → (criar Theme)

---

### Menus & Textos

**Specs**:
- Tamanho: 24-32pt (botões)
- Estilo: Sans-serif (arial, verdana)
- Cor: Preto/Branco

**Recomendação**: Manter simple (1-2 fontes max)

---

## 10.4 Cores & Paleta

### Paleta Recomendada (Escola Amigável)

```
Primária:    #FF6B35 (Laranja) - Galinha
Secundária:  #4ECDC4 (Turquesa) - Blocos
Destaque:    #FFD93D (Amarelo) - Vitória
Fundo:       #E8F4F8 (Azul claro) - Sky
Base:        #8B6F47 (Marrom) - Plataformas
Erro:        #E63946 (Vermelho) - Wrong
Sucesso:     #06D6A0 (Verde) - Correct
Texto:       #2D3436 (Preto) - Readability
```

### Ou Usar Paleta Existente
- **Lospec.com**: Procurar "platformer" ou "school"
- Descarregar `.png` com cores prontas

---

## 10.5 Adquirir Assets: Checklist

### Semana 1 (Antes de Terça)
- [ ] Definir estilo visual (pixel art vs clean)
- [ ] Procurar referências (jogos parecidos)
- [ ] Esboçar galinha em papel

### Semana 1 (Até Sexta)
- [ ] Galinha sprite pronta (pelo menos idle)
- [ ] Tileset básico esboçado
- [ ] Paleta de cores definida

### Semana 2 (Até Sexta)
- [ ] Blocos sprite pronta
- [ ] Tileset completo importado
- [ ] Background simples
- [ ] Sounds básicos encontrados

### Semana 3
- [ ] Tudo testado em Godot
- [ ] Ajustes finais de cor/tamanho
- [ ] Pronto pra polimento final

---

## 10.6 Ferramentas Recomendadas

### Desenho (FREE)
| Ferramenta | Uso | Custo |
|-----------|-----|-------|
| **Krita** | Pixel art + digital | Grátis |
| **Aseprite** | Pixel art (industry) | $20 ou grátis (compilar) |
| **Paint.NET** | Simples, rápido | Grátis |
| **Photopea** | Photoshop online | Grátis |

### Áudio (FREE)
| Ferramenta | Uso |
|-----------|-----|
| **Audacity** | Editar/gravar áudio |
| **Bfxr** | Gerar SFX retrô |
| **LMMS** | Compor música |

### Recursos (FREE)
| Site | O que tem |
|------|-----------|
| **itch.io/assets** | Sprites, áudio, tudo |
| **OpenGameArt** | Sprites de qualidade |
| **Freesound.com** | Efeitos sonoros |
| **Incompetech** | Músicas grátis |
| **Google Fonts** | Fontes incríveis |

---

## 10.7 Dicas de Qualidade

### Pixel Art
- ✅ Usar grid (sempre múltiplos de pixels)
- ✅ Poucar cores (10-16 per sprite)
- ✅ Alinhar sprites com grid do mundo
- ❌ Não misturar escalas (32px + 16px lado a lado fica estranho)

### Consistência
- ✅ Todos personagens mesmo tamanho relativo
- ✅ Blocos sempre 24x24 (nunca variar)
- ✅ Mesma paleta em tudo
- ✅ Mesmo estilo (pixel art ou clean, não misturar)

### Performance
- ✅ Usar PNG (melhor compressão)
- ✅ Remover fundo/transparência desnecessária
- ✅ Resoluções realistas (não 4K)
- ✅ Limpar metadados (Exif, etc)

---

## 10.8 Plano B: Assets Minimalistas

Se faltar tempo pro art:

```
Galinha:     Quadrado laranja com 2 pontinhos (olhos)
Bloco:       Quadrado amarelo + número
Plataforma:  Linha marrom horizontal
Background:  Cor sólida azul
UI:          Texto puro (sem ícones)
Sons:        Beeps do PC (sine wave simples)
Música:      Silêncio (opcional)
```

**Resultado**: Funcional + educacional indireto mantido
**Aparência**: Minimalista, tipo Flappy Bird

---

## Links Relacionados
- [[08_Divisao_Tarefas]] - Quem cria cada asset
- [[03_Mundo_Ambientacao]] - Visual detalhado
- [[04_UI_UX]] - Design de interface
