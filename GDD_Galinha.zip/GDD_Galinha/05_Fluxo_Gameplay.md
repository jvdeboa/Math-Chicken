# 5️⃣ Fluxo de Gameplay

## 5.1 Fluxo Principal

```
┌─────────────────┐
│  INICIALIZAR    │
│  Godot/Cenas    │
└────────┬────────┘
         ↓
┌─────────────────┐
│   MENU INICIAL  │ ← Jogar / Instruções / Créditos / Sair
└────────┬────────┘
         │ [JOGAR]
         ↓
┌─────────────────────────────────────────────────────────┐
│                    FASE 1                               │
│                                                         │
│  ┌──────────────────────────────────────────────────┐   │
│  │  5 + 3 = ?                                       │   │ ← Conta na tela
│  └──────────────────────────────────────────────────┘   │
│                                                         │
│  🐔 (galinha se move)                                   │
│  ▢ 8 ▢ (blocos flutuam)                               │
│                                                         │
│  ┌──────┐  ┌──────┐  ┌──────┐                          │
│  │      │  │      │  │      │ ← Plataformas           │
│  └──────┘  └──────┘  └──────┘                          │
└─────────────┬──────────────────────────────────────────┘
              │
       ┌──────┴────────┐
       │               │
  [Pegou Bloco]   [Pegou Bloco]
   Correto (8)     Errado
       │               │
       ↓               ↓
  ✅ FASE       ❌ ERRO
  COMPLETA!     (Volta início)
       │               │
       └───────┬───────┘
               ↓
         ┌──────────────┐
         │ PRÓXIMA FASE │
         └──────┬───────┘
                ↓
        [FASE 2, 3, ...]
                ↓
        ┌───────────────┐
        │ ÚLTIMA FASE?  │
        └────┬────┬─────┘
             │    │
        [SIM]│    │[NÃO]
             ↓    ↓
        FIM  PRÓX.FASE
        JOGO
             ↓
      ┌─────────────────┐
      │  TELA DE VITÓRIA│
      │  (parabéns!)    │
      └────────┬────────┘
               ↓
      [MENU INICIAL] ← Reiniciar, Sair
```

---

## 5.2 Fluxo de Fase Detalhado

```
┌──────────────────────────────────────┐
│  CARREGAR FASE                       │
│  - Gerar conta aleatória             │
│  - Posicionar galinha no spawn       │
│  - Spawnar blocos aleatoriamente     │
└──────────────┬───────────────────────┘
               ↓
┌──────────────────────────────────────┐
│  GAMEPLAY LOOP (Enquanto jogando)    │
│                                      │
│  1. Desenhar UI (conta)              │
│  2. Processar input (setas, espaço)  │
│  3. Atualizar galinha (posição, anim)│
│  4. Atualizar blocos                 │
│  5. Verificar colisões               │
│     ├─ Galinha + Bloco?              │
│     │  └─ Comparar bloco vs resposta │
│     │     ├─ Correto: Ganhou!       │
│     │     └─ Errado: Perde vida/     │
│     │        volta início             │
│     ├─ Galinha + Plataforma?         │
│     └─ Galinha + Limite do mundo?    │
│                                      │
│  6. Renderizar frame                 │
└──────────────┬───────────────────────┘
               ↓
         ┌─────────────┐
         │ Fase OK?    │
         └──┬──────┬───┘
       [SIM]│      │[NÃO]
            ↓      ↓
        VITÓRIA    LOOP
                   (volta pro passo 1)
            ↓
    ┌───────────────┐
    │ TELA VITÓRIA  │
    │ (Próxima/Menu)│
    └───────────────┘
```

---

## 5.3 Estados da Galinha

```
┌─────────────────┐
│     IDLE        │
│ (parado)        │
└────────┬────────┘
         ├─ Input movimento → WALKING
         └─ Input pulo → JUMPING
         
┌─────────────────┐
│    WALKING      │ (animação loop)
│ (andando)       │
└────────┬────────┘
         ├─ Soltou seta → IDLE
         └─ Input pulo → JUMPING
         
┌─────────────────┐
│    JUMPING      │ (subindo)
│ (pulando)       │
└────────┬────────┘
         └─ Toca solo → IDLE/WALKING
         
         (+ FALLING se cair)
```

---

## 5.4 Progressão Esperada

### Exemplo de Fluxo Real (3 Primeiras Fases)

**FASE 1: Adição Simples**
```
Conta: 2 + 1 = ?
Blocos: [1] [3] [2]
Resposta correta: 3
Dificuldade: Muito fácil - blocos próximos, visíveis
Tempo estimado: <2 minutos
```

**FASE 2: Adição Simples**
```
Conta: 3 + 2 = ?
Blocos: [5] [4] [6] [2]
Resposta correta: 5
Dificuldade: Fácil - um bloco mais escondido
Tempo estimado: 1-3 minutos
```

**FASE 3: Adição Simples**
```
Conta: 4 + 3 = ?
Blocos: [7] [5] [8] [6] [7]
Resposta correta: 7 (pode ser qualquer um dos dois 7s)
Dificuldade: Fácil - blocos espalhados, plataforma mais complexa
Tempo estimado: 2-4 minutos
```

---

## 5.5 Estrutura de Decisões (Diagrama)

```
JOGADOR PULA?
├─ SIM → Aplicar força pulo
│        └─ Em ar? → FALLING
│        └─ Em chão? → JUMPING
└─ NÃO → Sem movimento vertical

SETA ESQUERDA?
├─ SIM → Mover esquerda
│        └─ Animação WALKING
└─ NÃO → Sem movimento esquerdo

SETA DIREITA?
├─ SIM → Mover direita
│        └─ Animação WALKING
└─ NÃO → Sem movimento direito

NENHUMA SETA?
├─ SIM → Animação IDLE (parado)
└─ NÃO → Continuar último movimento

COLIDIU COM BLOCO?
├─ SIM → Verificar número
│        ├─ Número == Resposta?
│        │  ├─ SIM → FASE COMPLETA!
│        │  └─ NÃO → ERRO (volta início)
│        └─ Remover bloco
└─ NÃO → Continuar

CAIU DO MUNDO?
├─ SIM → Volta posição inicial
└─ NÃO → Continuar
```

---

## 5.6 Estados de Jogo Globais

| Estado | O que acontece |
|--------|---|
| **MENU** | Mostra menu inicial, aguarda input |
| **LOADING** | Carrega fase (transição) |
| **PLAYING** | Jogador controla a galinha |
| **PAUSED** | Menu de pausa sobreposto, jogo congelado |
| **PHASE_WON** | Mostra tela de vitória, aguarda próxima |
| **GAME_OVER** | (Opcional) Jogador perdeu todas as vidas |
| **GAME_COMPLETE** | Todas as fases completadas, tela final |

---

## Links Relacionados
- [[02_Mecanicas_Principais]] - Detalhes das mecânicas
- [[04_UI_UX]] - Interface durante gameplay
- [[06_Escopo_MVP]] - Quais fases fazer
- [[09_Arquitetura_Godot]] - Implementação
