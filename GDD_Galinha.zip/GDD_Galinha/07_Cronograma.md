# 7️⃣ Cronograma: Semana por Semana

**Formato**: Terças & Sextas, 3 horas cada = **6 horas/semana**

---

## 📅 Semana 1 (Hoje até ~24 de agosto)

### Terça (3 horas) - Setup & Player Básico
**Objetivo**: Ter galinha andando na tela

**Tarefas**:
- [ ] Setup novo projeto Godot 4
- [ ] Criar cena principal (Main.tscn)
- [ ] Criar CharacterBody2D para galinha
- [ ] Implementar movimento esquerda/direita (setas/WASD)
- [ ] Testar controles
- [ ] Salvar projeto no GitHub/Drive

**Checklist de Conclusão**:
- Galinha se move esquerda e direita
- Sem bugs de posicionamento
- Código salvo

### Sexta (3 horas) - Pulo & Plataformas
**Objetivo**: Galinha pulando, câmera funcionando

**Tarefas**:
- [ ] Implementar gravidade e detecção de solo
- [ ] Implementar pulo (espaço)
- [ ] Criar algumas plataformas (TileMap ou retângulos simples)
- [ ] Setup câmera seguindo galinha
- [ ] Testar física (pulo, queda)

**Checklist de Conclusão**:
- Galinha pula e cai corretamente
- Câmera segue suavemente
- Sem galinha caindo infinitamente

**Status Semana 1**: ✅ MVP ~30%

---

## 📅 Semana 2 (~25-31 de agosto)

### Terça (3 horas) - Sistema de Contas & HUD
**Objetivo**: Conta aparecendo na tela, verificação funcionando

**Tarefas**:
- [ ] Criar script `math_system.gd` - gera contas aleatórias
- [ ] Criar Label pra mostrar conta (topo da tela)
- [ ] Implementar verificação: bloco == resposta?
- [ ] Criar feedback inicial (pode ser console.log por enquanto)
- [ ] Testar com algumas contas diferentes

**Checklist de Conclusão**:
- Conta aparece no topo da tela (ex: "5 + 3 = ?")
- Resposta correta está guardada
- Verificação lógica funciona (testado via prints)

### Sexta (3 horas) - Blocos Numéricos & Colisão
**Objetivo**: Blocos na tela, colisão funciona

**Tarefas**:
- [ ] Criar cena `Block.tscn` (Area2D com Label)
- [ ] Implementar spawn aleatório de blocos
- [ ] Criar script pra detectar colisão galinha + bloco
- [ ] Implementar feedback (som/piscar) ao pegar
- [ ] Conectar à verificação de contas

**Checklist de Conclusão**:
- Blocos aparecem flutuando
- Galinha colide e pega o bloco
- Som/feedback ao pegar
- Verificação funciona (acerto vs erro)

**Status Semana 2**: ✅ MVP ~60%

---

## 📅 Semana 3 (~1-4 de setembro) - ⚠️ SEMANA FINAL

### Terça (3 horas) - Fases & Transição
**Objetivo**: Múltiplas fases funcionando

**Tarefas**:
- [ ] Criar script `level_manager.gd`
- [ ] Implementar 3-5 fases diferentes (cada uma com conta diferente)
- [ ] Transição entre fases (fade)
- [ ] Menu inicial simples (Jogar, Sair)
- [ ] Tela de vitória (Próxima Fase, Retry, Menu)

**Checklist de Conclusão**:
- Menu inicial funciona
- Fase 1 abre ao apertar "Jogar"
- Ao completar fase 1, fase 2 carrega
- Podem navegar entre fases
- Sair funciona

### Sexta (3 horas) - Testes & Polimento Final
**Objetivo**: Jogo 100% funcional para entrega

**Tarefas**:
- [ ] Testar jogo do início ao fim (3-5 fases)
- [ ] Corrigir bugs detectados
- [ ] Adicionar comentários nos scripts
- [ ] Criar README.md (como jogar)
- [ ] Preparar build final (.exe ou pasta Godot)
- [ ] Fazer backup no GitHub/Drive
- [ ] Preparar screenshots/video de gameplay

**Checklist de Conclusão**:
- ✅ Jogo roda sem crashes
- ✅ Todas as fases completáveis
- ✅ Feedback claro (som/visual)
- ✅ Documentação básica
- ✅ Pronto pra entrega

**Status Semana 3**: ✅ MVP 100% COMPLETO

---

## 📊 Resumo de Horas

| Semana | Terça | Sexta | Total | Status |
|--------|-------|-------|-------|--------|
| 1 | Setup Player | Pulo & Câmera | 6h | ~30% |
| 2 | Contas & HUD | Blocos & Colisão | 6h | ~60% |
| 3 | Fases & Menu | Testes & Polimento | 6h | ~100% |
| **TOTAL** | | | **18h** | ✅ Pronto |

---

## ⏰ Ao Longo de Cada Sessão (3 horas)

**Estrutura recomendada**:

```
0:00-0:10  Planejamento: O que vamos fazer hoje?
0:10-2:40  Desenvolvimento: Código + testes
2:40-3:00  Revisão: Funciona? Salvar? Documentar?
```

### Durante Desenvolvimento:
1. **Commit/Save a cada task completada** (Git ou Drive)
2. **Testar frequentemente** (não deixar bugs acumularem)
3. **Comunicar entre dupla** (quem está fazendo o quê)

---

## 🚨 Sinais de Alerta (Red Flags)

Se algo disso acontecer, **adapte o plano**:

| Red Flag | Ação |
|----------|------|
| Semana 1 termina sem player andando | Simplificar, pedir ajuda |
| Semana 2 termina sem blocos funcionando | Remover animações complexas |
| Semana 3 terça, tem só 1 fase | Reduzir para 3 fases finais |
| Bugs críticos (crash ao pegar bloco) | Parar tudo e debugar |
| Não tem tempo pra testar | Entrega mesmo com bugs, mas funcional |

---

## 💡 Dicas Práticas

### Salvar & Backup
- Comitar no GitHub **a cada sessão**
- Backup no Google Drive também
- Não confiar em "vou salvar depois"

### Comunicação Dupla
- Combinar antes da sessão: quem faz o quê?
- Trocar mensagens entre sessões (progresso)
- Reunião de 5min sexta à noite pra planejar terça

### Debugging
- Usar `print()` pra testar valores
- Testar CADA coisa isolada antes de juntar
- Se bugou, voltar ao último commit que funcionava

### Qualidade
- 1 fase perfeita > 10 fases com bugs
- Focar em funcionalidade primeiro, depois visual

---

## 📝 Template de Relatório Semanal

**Salvar em `RELATORIO_SEMANA_X.md`:**

```markdown
## Semana 1 - Relatório

### O que foi feito (Terça)
- [x] Setup Godot
- [x] Player movement
- [ ] Animação

### O que foi feito (Sexta)
- [x] Pulo
- [x] Câmera
- [ ] Plataformas

### Próximos passos
- Terminar plataformas
- Contas

### Desafios encontrados
- Godot crashava ao mudar cena (resolvido)
- Physics estranha inicialmente (ajustado)

### Horas gastas
- Terça: 3h
- Sexta: 3h
- Total: 6h
```

---

## Links Relacionados
- [[06_Escopo_MVP]] - Entender prioridades
- [[08_Divisao_Tarefas]] - Coordenar entre dupla
- [[09_Arquitetura_Godot]] - Detalhes técnicos
