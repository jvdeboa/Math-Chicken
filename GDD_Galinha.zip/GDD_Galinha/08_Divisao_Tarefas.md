# 8️⃣ Divisão de Tarefas

## 🎯 Estratégia Geral

**Opção A (Recomendada)**: Especialização por área
- **Pessoa A**: Programação (Godot/GDScript)
- **Pessoa B**: Arte & Design (Sprites, UI, assets)

**Opção B (Flexível)**: Trabalho paralelo por sprint
- Ambos programam, ambos fazem arte (se ambos souberem)

**Opção C (Híbrida)**: Pessoa principal + apoio
- **Pessoa A**: Coordena e programa tudo
- **Pessoa B**: Suporta arte + testes + documentação

---

## 📋 Opção A: Especialização (RECOMENDADA)

### 👨‍💻 **Pessoa A - Programação Godot**

#### Responsabilidades Principais:
- Setup do projeto Godot
- Estrutura de cenas e scripts
- Mecânicas de gameplay

#### Tarefas Específicas:

**Semana 1 (Terça)**
- [ ] Criar projeto novo
- [ ] Cena principal (Main.tscn)
- [ ] Script player.gd (movimento esquerda/direita)
- [ ] Testar controles

**Semana 1 (Sexta)**
- [ ] Adicionar gravidade ao player
- [ ] Pulo (implementar força)
- [ ] Detecção de solo
- [ ] Câmera seguindo player

**Semana 2 (Terça)**
- [ ] Script math_system.gd (gerar contas aleatórias)
- [ ] UI Manager: mostrar conta na tela
- [ ] Função de verificação (bloco == resposta?)
- [ ] System de feedback (prints por enquanto)

**Semana 2 (Sexta)**
- [ ] Script block_manager.gd (spawn de blocos)
- [ ] Area2D pra colisão
- [ ] Conectar verificação à colisão
- [ ] System de sons (simples, beeps)

**Semana 3 (Terça)**
- [ ] Script level_manager.gd (fases)
- [ ] Múltiplas fases (data/arrays)
- [ ] Transição entre fases
- [ ] Menu inicial (simples)
- [ ] Tela vitória fase

**Semana 3 (Sexta)**
- [ ] Testes integrados (menu → gameplay → vitória)
- [ ] Corrigir bugs críticos
- [ ] Comentar código
- [ ] Preparar build final

#### Skills Necessárias:
- ✅ GDScript básico
- ✅ Godot nodes/scenes
- ✅ Physics 2D
- ✅ Sinais/eventos

#### Ferramentas:
- Godot 4 Editor
- VS Code (pra editar scripts)
- Git (versionamento)

---

### 🎨 **Pessoa B - Arte & Design**

#### Responsabilidades Principais:
- Sprites e animações
- UI visual (menus, HUD)
- Tileset/plataformas
- Feedback visual (efeitos, cores)

#### Tarefas Específicas:

**Semana 1 (Terça)**
- [ ] Criar/adaptar sprite galinha simples
- [ ] Esboçar tileset básico
- [ ] Cores e paleta do projeto
- [ ] Começar a entender visual do jogo

**Semana 1 (Sexta)**
- [ ] Sprite galinha com 2-3 frames (walk, idle, jump)
- [ ] Spritesheet montada
- [ ] Tileset básico (plataformas)
- [ ] Fundo simples pra cena

**Semana 2 (Terça)**
- [ ] Design HUD (conta na tela)
- [ ] Sprite dos blocos (com números)
- [ ] Botões pra menu (visual)
- [ ] Feedback visual (cores pra acerto/erro)

**Semana 2 (Sexta)**
- [ ] Tela de vitória (design)
- [ ] Tela de menu (design)
- [ ] Efeitos visuais simples (brilhos)
- [ ] Cores finais e ajustes

**Semana 3 (Terça)**
- [ ] Polimento visual geral
- [ ] Animações adicionais (se tempo)
- [ ] Assets faltantes
- [ ] Screenshots para documentação

**Semana 3 (Sexta)**
- [ ] Ajustes finais de visual
- [ ] Testes com programmer (se fica bom?)
- [ ] Preparar imagens/video de gameplay

#### Skills Necessárias:
- ✅ Desenho/pixel art (básico)
- ✅ Software: Aseprite, Krita, ou até Paint
- ✅ Entender proporcões/grid
- ✅ Noção de design UI

#### Ferramentas:
- Aseprite (recomendado) OU Krita (free) OU Paint/Photoshop
- Google Sheets (pra documentar specs visuais)
- Godot (pra testar assets)

---

## 📊 Mapa de Dependências

```
PESSOA A (Programação)          PESSOA B (Arte)
├─ Setup Godot                  ├─ Galinha sprite
├─ Player movement              ├─ Tileset
├─ Pulo & Física                ├─ HUD design
│  (precisa arte pra testar)    │  (Pessoa A aplica)
├─ Contas & Blocos              ├─ Blocos sprite
│  (Pessoa B faz sprite)        ├─ Menu design
├─ Colisão                      └─ Efeitos visuais
├─ Fases & Menu
│  (Pessoa B faz UI)
└─ Testes & Bugfix

Comunicação necessária:
- Terça/Sexta: "Pessoa B faz spritesheet de galinha"
  → "Pessoa A importa e testa animação"
- Spritesheet pronto? → Pessoa A consegue programar
- Tamanho sprite ok? → Pessoa B ajusta ou pessoa A reclama
```

---

## 💬 Comunicação entre Dupla

### Check-in Rápido (5 min)
- **Antes de começar**: "Oi, hoje eu vou fazer X, você faz Y?"
- **Após sessão**: "Consegui fazer [tarefa], pronto pra você usar"

### Check-out Rápido (5 min)
- **Fim de sexta**: Revisar progresso
- **Planejar terça**: "Semana que vem preciso de..."

### Exemplo de Conversa:

**Terça de manhã**:
> A: "Oi! Hoje vou fazer o movimento do player e câmera"
> B: "Tô fazendo a sprite da galinha, manda aviso quando acabar"
> A: "Pronto, importa o arquivo XY da minha drive"
> B: "✓ Importei, ficou legal!"

**Sexta de tarde**:
> B: "Finalizei o sprite walking e os blocos (com números)"
> A: "Ótimo, importei e já tá animando. Manda tudo pro GitHub?"
> B: "Já foi!"
> A: "Semana que vem preciso da tela de vitória até terça, beleza?"
> B: "Tranquilo, já tô preparando"

---

## 🔄 Como Compartilhar Assets

### Via Google Drive (Recomendado)
```
GDD_Galinha_Assets/
├── Sprites/
│   ├── galinha_walk.aseprite
│   ├── galinha_walk.png (exportado)
│   ├── blocks.png
│   └── tileset.png
├── UI/
│   ├── menu_sketch.png
│   └── hud_design.png
└── Design/
    └── color_palette.png
```

### Via GitHub (Se souberem Git)
```bash
git add Assets/
git commit -m "Add galinha sprites e tileset"
git push origin main
```

---

## ✅ Checklist de Coordenação

### Semana 1 Pós-Terça:
- [ ] Pessoa A: Código funciona (movimento OK)
- [ ] Pessoa B: Sprite base galinha pronta
- [ ] Pessoa B mandou sprite via Drive/GitHub

### Semana 1 Pós-Sexta:
- [ ] Pessoa A: Pulo + câmera funcionando
- [ ] Pessoa B: Spritesheet walk/idle/jump pronta
- [ ] Pessoa A: Importou e testou no Godot

### Semana 2 Pós-Terça:
- [ ] Pessoa A: Math system + HUD funcionando
- [ ] Pessoa B: Design HUD pronto, blocos desenhados
- [ ] Integração: A aplica visual de B

### Semana 2 Pós-Sexta:
- [ ] Pessoa A: Blocos e colisão funcionando
- [ ] Pessoa B: Telas de menu/vitória finalizadas
- [ ] Tudo importado e testado

### Semana 3 Pós-Terça:
- [ ] Pessoa A: 3-5 fases + menu funcionando
- [ ] Pessoa B: Todos assets visuais prontos
- [ ] Pessoa A: Aplicou toda arte no jogo

### Semana 3 Pós-Sexta:
- [ ] ✅ JOGO PRONTO PENSA TESTES
- [ ] [ ] README escrito
- [ ] [ ] Screenshots tiradas
- [ ] [ ] Pronto pra entrega

---

## 🚨 E se Um Ficar Atrasado?

### Pessoa A (Programmer) atrasou
**Plano B:**
- Pessoa B faz testes manuais (abre Godot, testa mecânica)
- Pessoa A trabalha horas extra pra alcançar
- Remover features opcionais (som, efeitos)

### Pessoa B (Artist) atrasou
**Plano B:**
- Usar assets simples (formas geométricas)
- Pessoa A programa com placeholder visual
- Polimento vem depois (não é bloqueante)

### Ambos atrasados (Semana 3)
**Prioridade**:
1. **Funcionabilidade**: Jogo funciona 100% com 3 fases
2. **Visual básico**: Se der tempo, visual melhor
3. **Polish**: Efeitos, animações complexas → REMOVE

---

## 📚 Recursos Úteis

### Pra Programador (Pessoa A)
- Documentação Godot: https://docs.godotengine.org/
- GDScript Cheat Sheet
- Discord Godot Brasil (pra tirar dúvida)

### Pra Artista (Pessoa B)
- Aseprite: https://www.aseprite.org (pago, versão grátis)
- Krita: https://krita.org (grátis, ótimo)
- itch.io/assets (pra referência)
- Lospec.com (paletas de cores prontas)

---

## Links Relacionados
- [[07_Cronograma]] - Quando cada coisa acontece
- [[06_Escopo_MVP]] - O que cada um vai entregar
- [[09_Arquitetura_Godot]] - Detalhes técnicos pro programmer
